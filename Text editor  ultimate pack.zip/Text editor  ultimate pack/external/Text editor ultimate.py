from tkinter import *
from tkinter import scrolledtext
from tkinter import filedialog
from tkinter import messagebox
import sys

def open_file():
    file = filedialog.askopenfile(mode = "r")
    if file != None:
        text.delete("1.0", END)
        text.insert("1.0", file.read())
        file.close()

def save_file():
    file = filedialog.asksaveasfile(mode = "w")
    if file != None:
        file.write(text.get("1.0", END))
        file.close()

def about_dialog():
    messagebox.showinfo("About", "Version 3.4.2 \nEnjoy!")

def why_dialog():
    messagebox.showinfo("why?", "The best way way to write virtual books! take your time to do your document you have as long as it takes\nEnjoy!")


def patch_notes():
    messagebox.showinfo("Patch notes", "Exe change and we are going to update it more on intertext")

def how_to_use():
    messagebox.showinfo("how to use", "to use you can type using your device or click file to see more options and to save you must open the file explorer and save it to any file you want!")

# info buttons
def info():
    messagebox.showinfo("Info", "Welcome to the info area we here try and walk you through the new updates and first we are updating this area which is also will help if you are using the demo or full version but we are planning a big update at the end of the month!")

def what_code_language_we_used():
    messagebox.showinfo("Python", "Python is a free coding IDE and language that you can get from python.org")
    messagebox.showinfo("sys", "sys is a python module that you can import from saying 'import sys'")

def Website():
    messagebox.showinfo("Website", "biggyv1.wixsite.com/intertext")
    
def exit_app():
    sys.exit(0)

root_win = Tk()
root_win.title("Text Editor Ultimate")
root_win.geometry("640x480")

main_menu = Menu(root_win)
root_win.config(menu = main_menu)

# file menu
file_menu = Menu(main_menu)
main_menu.add_cascade(label="File", menu = file_menu)
file_menu.add_command(label="Open", command = open_file)
file_menu.add_command(label="Save", command = save_file)
file_menu.add_command(label="About", command = about_dialog)
file_menu.add_command(label="Exit", command = exit_app)
file_menu.add_command(label="Why", command = why_dialog)
# info menu
secondary_menu = Menu(main_menu)
main_menu.add_cascade(label="info", menu = secondary_menu)
secondary_menu.add_command(label="info", command = info)
secondary_menu.add_command(label="what code language we used", command = what_code_language_we_used)
secondary_menu.add_command(label="Patch notes", command = patch_notes)
secondary_menu.add_command(label="How to use", command = how_to_use)
secondary_menu.add_command(label="Website", command = Website)
text = scrolledtext.ScrolledText(root_win, width = 80, height = 30)
text.pack(fill = "both", expand = "yes")

root_win.mainloop()


app.run()